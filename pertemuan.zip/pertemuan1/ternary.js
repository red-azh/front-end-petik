/** @format */

const age = 19;

const status = age > 21 ? "Dewasa" : age < 7 ? "bocil parah" : "tua";

const name = "ucup";
const age =20;
const isMaried = false;
let tglLahir= "2004-02-10";
// ini buat ngecek nilai type data
console.log(typeof age); //pakai typeof (nama_variable)
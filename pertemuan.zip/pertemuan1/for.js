// for itu memiliki 3 argumen
for (let i = 9; i <= 10; i++) {
    console.log(`ini perulangan ke-${i}`);
    
}
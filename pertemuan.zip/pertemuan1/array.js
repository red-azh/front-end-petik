/** @format */

const fruits = ["apel", "Anggur", "Jeruk"];
// console.log(fruits[0]);

// looping (untuk akses value array)
// for (let i = 0; i  < fruits.length; i++){
//     console.log(fruits[i]);
// }

// looping for-of
for (const fruit of fruits) console.log(fruit);
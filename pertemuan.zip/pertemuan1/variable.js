// dijalankan sebelum di deklarasikan (hoisting)
// var bisa dijalankan diatas pemanggil atau pun dibawah pemanggil
var nama = "ucup";
let age = 20;
const gender = 'l';
console.log(nama);

/** @format */

const user = {
	name: "Budi",
	age: 20,
	major: "Informatika",
};

// const {nama, age , major} = user
// opsi kedua nenbuat object di javascript
const nama = user.name;
const umur = user.age;
console.log(nama);

/** @format */

const fruits = ["Apel", "Mangga", "Jeruk", "Anggur"];
// destruc = menghancurkan array dan membuat menajdi nilai string tersendiri
// ini adalah membuat destruc dan ini nama variable yang merah ini variable, dan harus berurutan
// const [merah, hijau, kuning, unggu ] = fruits;

// ini opsi kedua unutk men destrruc array yang lebih custom cuman jadi lebih panjang kodenya
const merah = fruits[0];
const hijau = fruits[1];
const kuning = fruits[2];
const ungu = fruits[3];
console.log(ungu);


// intinya destruc array adalah untuk membuat jadi satu nilai variable
